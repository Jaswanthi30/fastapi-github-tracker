import os
import requests

# GitHub API base URL 
GITHUB_API = os.getenv("GITHUB_API_BASE", "https://api.github.com")


def fetch_repo(owner: str, repo: str) -> dict:
    """
    Fetch GitHub repository details using GitHub REST API.
    (Synchronous version using requests)
    """
    url = f"{GITHUB_API}/repos/{owner}/{repo}"

    response = requests.get(url, timeout=5)
    response.raise_for_status()
    return response.json()



# Standalone test runner

if __name__ == "__main__":
    data = fetch_repo("tiangolo", "fastapi")
    print("Repository name :", data["name"])
    print("Stars           :", data["stargazers_count"])
    print("Language        :", data["language"])
