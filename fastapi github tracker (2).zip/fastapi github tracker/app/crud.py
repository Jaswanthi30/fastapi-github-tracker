from sqlalchemy import Column, Integer, String, create_engine
from sqlalchemy.orm import declarative_base, sessionmaker, Session

# -----------------------------
# Database (SQLite for safety)
# -----------------------------
DATABASE_URL = "sqlite:///./repos.db"

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False}
)

SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()


# -----------------------------
# Model
# -----------------------------
class Repository(Base):
    __tablename__ = "repositories"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    owner = Column(String, nullable=False)
    stars = Column(Integer, nullable=False)


Base.metadata.create_all(bind=engine)


# -----------------------------
# CRUD functions
# -----------------------------
def create_repo(db: Session, data: dict):
    repo = Repository(**data)
    db.add(repo)
    db.commit()
    db.refresh(repo)
    return repo


def get_repo(db: Session, repo_id: int):
    return db.query(Repository).filter(Repository.id == repo_id).first()


def update_repo(db: Session, repo_id: int, stars: int):
    repo = get_repo(db, repo_id)
    if repo:
        repo.stars = stars
        db.commit()
        db.refresh(repo)
    return repo


def delete_repo(db: Session, repo_id: int):
    repo = get_repo(db, repo_id)
    if repo:
        db.delete(repo)
        db.commit()
    return repo


# -----------------------------
# SELF TEST (PROVES IT WORKS)
# -----------------------------
if __name__ == "__main__":
    db = SessionLocal()

    print("Creating repo...")
    r = create_repo(db, {
        "name": "fastapi",
        "owner": "tiangolo",
        "stars": 1000
    })

    print("Created:", r.id, r.name, r.owner, r.stars)

    print("Updating stars...")
    update_repo(db, r.id, 2000)

    print("Fetching repo...")
    r2 = get_repo(db, r.id)
    print("Fetched:", r2.id, r2.name, r2.stars)

    print("Deleting repo...")
    delete_repo(db, r.id)

    print("DONE — NO IMPORT ERRORS")
