from pydantic import BaseModel

class RepoCreate(BaseModel):
    owner: str
    repo_name: str

class RepoUpdate(BaseModel):
    stars: int

class RepoResponse(BaseModel):
    id: int
    name: str
    owner: str
    stars: int

    class Config:
        orm_mode = True
