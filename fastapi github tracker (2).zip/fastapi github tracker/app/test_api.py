print(" SCRIPT STARTED ")

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from main import Base, create_repo, get_all_repos, fetch_repo

print(" Imports successful")

engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
Session = sessionmaker(bind=engine)
Base.metadata.create_all(bind=engine)

db = Session()

print("Testing fetch_repo...")
data = fetch_repo("tiangolo", "fastapi")
print("Repo name:", data["name"])

print(" Testing create_repo...")
repo = create_repo(db, {
    "name": "fastapi",
    "owner": "tiangolo",
    "stars": 1000
})
print("Saved repo ID:", repo.id)

print(" Testing get_all_repos...")
repos = get_all_repos(db)
print("Repos in DB:", repos)

print(" SCRIPT FINISHED SUCCESSFULLY")
