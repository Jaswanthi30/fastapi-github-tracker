import pytest
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.orm import sessionmaker, declarative_base, Session

# Database setup

SQLALCHEMY_DATABASE_URL = "sqlite:///./test.db"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class Repo(Base):
    __tablename__ = "repos"

    id = Column(Integer, primary_key=True, index=True)
    owner = Column(String)
    name = Column(String)
    stars = Column(Integer, default=0)


Base.metadata.create_all(bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# FastAPI app
app = FastAPI()


@app.get("/")
def root():
    return {"message": "API is working"}


@app.post("/repos", status_code=201)
def create_repo(repo: dict, db: Session = Depends(get_db)):
    new_repo = Repo(
        owner=repo["owner"],
        name=repo["repo_name"],
        stars=repo.get("stars", 0),
    )
    db.add(new_repo)
    db.commit()
    db.refresh(new_repo)
    return {
        "id": new_repo.id,
        "owner": new_repo.owner,
        "name": new_repo.name,
        "stars": new_repo.stars,
    }


@app.get("/repos/{repo_id}")
def get_repo(repo_id: int, db: Session = Depends(get_db)):
    repo = db.query(Repo).filter(Repo.id == repo_id).first()
    if not repo:
        raise HTTPException(status_code=404, detail="Repo not found")
    return repo


@app.put("/repos/{repo_id}")
def update_repo(repo_id: int, data: dict, db: Session = Depends(get_db)):
    repo = db.query(Repo).filter(Repo.id == repo_id).first()
    if not repo:
        raise HTTPException(status_code=404)
    repo.stars = data["stars"]
    db.commit()
    return {"stars": repo.stars}


@app.delete("/repos/{repo_id}", status_code=204)
def delete_repo(repo_id: int, db: Session = Depends(get_db)):
    repo = db.query(Repo).filter(Repo.id == repo_id).first()
    if not repo:
        raise HTTPException(status_code=404)
    db.delete(repo)
    db.commit()


# Tests
client = TestClient(app)


def test_root():
    res = client.get("/")
    assert res.status_code == 200
    assert "message" in res.json()


def test_create_repo():
    res = client.post("/repos", json={"owner": "tiangolo", "repo_name": "fastapi"})
    assert res.status_code == 201
    assert "id" in res.json()


def test_repo_not_found():
    res = client.get("/repos/999")
    assert res.status_code == 404


def test_update_repo():
    res = client.post("/repos", json={"owner": "psf", "repo_name": "requests"})
    repo_id = res.json()["id"]

    res = client.put(f"/repos/{repo_id}", json={"stars": 5000})
    assert res.status_code == 200
    assert res.json()["stars"] == 5000


def test_delete_repo():
    res = client.post("/repos", json={"owner": "abc", "repo_name": "xyz"})
    repo_id = res.json()["id"]

    res = client.delete(f"/repos/{repo_id}")
    assert res.status_code == 204
