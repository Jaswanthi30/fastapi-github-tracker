DATABASE_URL=postgresql://postgres:password@localhost:5432/github_db
GITHUB_API_BASE=https://api.github.com
set DATABASE_URL=postgresql://postgres:password@localhost:5432/github_db
