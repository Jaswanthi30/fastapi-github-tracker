import requests
from fastapi import FastAPI, HTTPException, Depends
from sqlalchemy import Column, Integer, String, create_engine
from sqlalchemy.orm import declarative_base, sessionmaker, Session
from pydantic import BaseModel

# Database setup
DATABASE_URL = "sqlite:///./repos.db"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()


# SQLAlchemy Model
class Repository(Base):
    __tablename__ = "repositories"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    owner = Column(String, nullable=False)
    stars = Column(Integer, nullable=False)

# Create tables
Base.metadata.create_all(bind=engine)

# Pydantic Schemas
class RepoCreate(BaseModel):
    owner: str
    repo_name: str

class RepoUpdate(BaseModel):
    stars: int

class RepoResponse(BaseModel):
    id: int
    name: str
    owner: str
    stars: int

    class Config:
        orm_mode = True  # allow returning SQLAlchemy models


# CRUD Functions
def create_repo(db: Session, data: dict) -> Repository:
    repo = Repository(**data)
    db.add(repo)
    db.commit()
    db.refresh(repo)
    return repo

def get_repo(db: Session, repo_id: int) -> Repository | None:
    return db.query(Repository).filter(Repository.id == repo_id).first()

def update_repo(db: Session, repo_id: int, stars: int) -> Repository | None:
    repo = get_repo(db, repo_id)
    if repo:
        repo.stars = stars
        db.commit()
        db.refresh(repo)
    return repo

def delete_repo(db: Session, repo_id: int) -> Repository | None:
    repo = get_repo(db, repo_id)
    if repo:
        db.delete(repo)
        db.commit()
    return repo

def get_all_repos(db: Session):
    return db.query(Repository).all()

# External GitHub API Fetch
GITHUB_API_BASE = "https://api.github.com"

def fetch_github_repo(owner: str, repo_name: str) -> dict:
    url = f"{GITHUB_API_BASE}/repos/{owner}/{repo_name}"
    response = requests.get(url, timeout=5)
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail="GitHub repo not found")
    return response.json()


# FastAPI App
app = FastAPI(title="GitHub Repo Tracker")

# Dependency to get DB session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# API Endpoints

# POST - create repo from GitHub API
@app.post("/repos", response_model=RepoResponse, status_code=201)
def create_repository(payload: RepoCreate, db: Session = Depends(get_db)):
    data = fetch_github_repo(payload.owner, payload.repo_name)
    repo_data = {
        "name": data["name"],
        "owner": data["owner"]["login"],
        "stars": data["stargazers_count"]
    }
    repo = create_repo(db, repo_data)
    return repo

# GET - fetch repo by ID
@app.get("/repos/{repo_id}", response_model=RepoResponse)
def read_repository(repo_id: int, db: Session = Depends(get_db)):
    repo = get_repo(db, repo_id)
    if not repo:
        raise HTTPException(status_code=404, detail="Repository not found")
    return repo

# PUT - update stars
@app.put("/repos/{repo_id}", response_model=RepoResponse)
def update_repository(repo_id: int, payload: RepoUpdate, db: Session = Depends(get_db)):
    repo = update_repo(db, repo_id, payload.stars)
    if not repo:
        raise HTTPException(status_code=404, detail="Repository not found")
    return repo

# DELETE - delete repo
@app.delete("/repos/{repo_id}", status_code=204)
def delete_repository(repo_id: int, db: Session = Depends(get_db)):
    repo = delete_repo(db, repo_id)
    if not repo:
        raise HTTPException(status_code=404, detail="Repository not found")
    return

@app.get("/")
def root():
    return {"message": "GitHub Repo Tracker API is running!"}


# Run standalone
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
